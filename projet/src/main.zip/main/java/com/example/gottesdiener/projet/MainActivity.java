package com.example.gottesdiener.projet;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.LinearLayout;



public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        TranslateAnimation translateAnimation = new TranslateAnimation(1100,0,0,0);
        translateAnimation.setStartOffset(1100);
        translateAnimation.setFillAfter(true);
        translateAnimation.setDuration(1000);

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.layout);
        linearLayout.startAnimation(translateAnimation);

    }


    public void editTex(View view){
        EditText editText = (EditText) view;
        editText.setText("");
        if (editText.getId() == R.id.editText) editText.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_CLASS_TEXT);
    }

    public void renvoi(View view){
        switch (view.getId()){
            case R.id.connec : {
                if (getResources().getBoolean(R.bool.isSmartphone) || getResources().getBoolean(R.bool.isTabletPort)){
                    Intent intent = new Intent(this,ListBooksActivity.class);
                    this.startActivityForResult(intent,1000);
                }else{
                    Intent intent = new Intent(this,FragmentActivity.class);
                    this.startActivityForResult(intent,1000);
                }
                break;
            }
            case R.id.oublier : break;
            case R.id.creer : {
                Intent intent = new Intent(this,Creation.class);
                this.startActivityForResult(intent,1000);

                break;
            }
        }
    }

    public void password (View v){
        Intent intent = new Intent(this,MdpActivity.class);
        startActivity(intent);
    }

}
