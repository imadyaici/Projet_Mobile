package com.example.gottesdiener.projet;

import android.annotation.TargetApi;
import android.app.SearchManager;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.widget.Spinner.*;


public class ListBooksActivity extends ActionBarActivity implements SearchView.OnQueryTextListener
        ,OnItemClickListener, OnItemSelectedListener{

    ArrayList<Livre> listeLivres = new ArrayList<Livre>();
    ImageView imageView;
    Resources resources;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_books);

        ActionBar ab = getSupportActionBar();
        ab.hide();

        resources = getResources();
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("Informatique","11 minutes","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("Informatique","Arrêtez de méprisez les français","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("Informatique","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("Informatique","11 ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("Informatique","Arrêtez ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("Informatique","Anges ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("Informatique","11 minutes   ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("Informatique","Arrêtez de méprisez les français   ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("Informatique","Anges ou Démons   ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("Informatique","11 minutes","Paulo Coelo","Résumé",imageView));

        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("electronique","Arrêtez de méprisez les français","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electronique","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electronique","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("electronique","11 ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("electronique","Arrêtez ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electronique","Anges ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("electronique","11 minutes   ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("electronique","Arrêtez de méprisez les français   ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electronique","Anges ou Démons   ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("electronique","11 minutes","Paulo Coelo","Résumé",imageView));

        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("electricite","Arrêtez de méprisez les français","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electricite","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electricite","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("electricite","11 ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("electricite","Arrêtez ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electricite","Anges ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("electricite","11 minutes   ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("electricite","Arrêtez de méprisez les français   ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("electricite","Anges ou Démons   ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("electricite","11 minutes","Paulo Coelo","Résumé",imageView));

        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("architecture","Arrêtez de méprisez les français","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("architecture","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("architecture","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("architecture","11 ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("architecture","Arrêtez ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("architecture","Anges ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("architecture","11 minutes   ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("architecture","Arrêtez de méprisez les français   ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("architecture","Anges ou Démons   ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("architecture","11 minutes","Paulo Coelo","Résumé",imageView));

        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("optique","Arrêtez de méprisez les français","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("optique","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("optique","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("optique","11 ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("optique","Arrêtez ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("optique","Anges ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("optique","11 minutes   ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("optique","Arrêtez de méprisez les français   ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("optique","Anges ou Démons   ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("optique","11 minutes","Paulo Coelo","Résumé",imageView));

        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("organisation","Arrêtez de méprisez les français","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("organisation","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("organisation","Anges ou Démons","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("organisation","11 ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("organisation","Arrêtez ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("organisation","Anges ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("organisation","11 minutes   ","Paulo Coelo","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher2));
        listeLivres.add(new Livre("organisation","Arrêtez de méprisez les français   ","Hervé Morin","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher3));
        listeLivres.add(new Livre("organisation","Anges ou Démons   ","Dan Brown","Résumé",imageView));
        imageView = new ImageView(this);
        imageView.setBackgroundDrawable(resources.getDrawable(R.drawable.ic_launcher1));
        listeLivres.add(new Livre("organisation","11 minutes","Paulo Coelo","Résumé",imageView));


        ListView listView = (ListView) this.findViewById(R.id.listview);
        MonAdaptateur monAdapteteur = new MonAdaptateur(this,listeLivres,10);
        listView.setAdapter(monAdapteteur);
        listView.setOnItemClickListener(this);

        SearchView searchView = (SearchView) findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(this);

        Spinner spinner = (Spinner) findViewById(R.id.spinnerab);
        spinner.setOnItemSelectedListener(this);
    }



    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void marquerInteressante(View view){
        ImageView imageView = (ImageView) view;
        imageView.setBackgroundDrawable(getResources().getDrawable(R.drawable.gold_star));
        Toast.makeText(this,"Catégorie ajoutée au favories",Toast.LENGTH_SHORT).show();
    }

    public ArrayList<Livre> filtreCategorie(ArrayList<Livre> listBooks, String categorie){
        ArrayList<Livre> filtredList = new ArrayList<Livre>();
        for (int i=0;i<listBooks.size();i++){
            if (listBooks.get(i).getCategorie().toLowerCase().equals(categorie.toLowerCase())) filtredList.add(listBooks.get(i));
        }
        return filtredList;
    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        ListView listView = (ListView) findViewById(R.id.listview);
        listView.setVisibility(View.GONE);

        TextView titreLivre = (TextView) view.findViewById(R.id.titreLivre);
        TextView auteurLivre = (TextView) view.findViewById(R.id.auteurLivre);
        TextView categorieLivre = (TextView) view.findViewById(R.id.categorieLivre);
        TextView resumeLivre = (TextView) view.findViewById(R.id.resumeLivre);
        TextView anneeEditionLivre = (TextView) view.findViewById(R.id.anneeEditionLivre);
        ImageView couvertureLivre = (ImageView) findViewById(R.id.imageLivre);

        Intent intent = new Intent(this,DetailBookActivity.class);
        intent.putExtra("titre",titreLivre.getText().toString());
        intent.putExtra("auteur",auteurLivre.getText().toString());
        intent.putExtra("categorie",categorieLivre.getText().toString());
        intent.putExtra("resume",resumeLivre.getText().toString());
        intent.putExtra("annee",anneeEditionLivre.getText().toString());
        this.startActivityForResult(intent,1000);

    }

    public ArrayList<Livre> filtredListBooks(ArrayList<Livre> listBooks, String query){
        ArrayList<Livre> filtredList = new ArrayList<Livre>();
        for (int i=0;i<listBooks.size();i++){
            if (listBooks.get(i).containAllKeyWords(query)) filtredList.add(listBooks.get(i));
        }
        return filtredList;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        ArrayList<Livre> list = filtredListBooks(listeLivres,query);
        MonAdaptateur monAdapteteur = new MonAdaptateur(this,list,10);
        ListView listView = (ListView) findViewById(R.id.listview);
        listView.setAdapter(monAdapteteur);
        listView.setOnItemClickListener(this);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        return false;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String categorie = (String) parent.getItemAtPosition(position);
        imageView = (ImageView) findViewById(R.id.star);
        imageView.setVisibility(View.GONE);
        if (!categorie.equalsIgnoreCase("Catégorie")){
            imageView.setBackgroundDrawable(getResources().getDrawable(R.drawable.white_star));
            imageView.setVisibility(VISIBLE);

            ArrayList<Livre> list = filtreCategorie(listeLivres, categorie);
            MonAdaptateur monAdapteteur = new MonAdaptateur(this,list,10);
            ListView listView = (ListView) findViewById(R.id.listview);
            listView.setAdapter(monAdapteteur);
            listView.setOnItemClickListener(this);
            Log.e("List",list.toString());
        }else{
            ListView listView = (ListView) this.findViewById(R.id.listview);
            MonAdaptateur monAdapteteur = new MonAdaptateur(this,listeLivres,10);
            listView.setAdapter(monAdapteteur);
            listView.setOnItemClickListener(this);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
