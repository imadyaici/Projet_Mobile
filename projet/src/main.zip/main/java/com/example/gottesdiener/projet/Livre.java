package com.example.gottesdiener.projet;

import android.widget.ImageView;

/**
 * Created by Gottesdiener on 24/03/2015.
 */
public class Livre {
    private String categorie;
    private String titre;
    private String auteur;
    private String anneeEdition;
    private String resume;
    private ImageView imageView;

    public Livre(String categorie, String titre, String auteur, String anneeEdition, String resume, ImageView imageView) {
        this.categorie = categorie;
        this.titre = titre;
        this.auteur = auteur;
        this.anneeEdition = anneeEdition;
        this.resume = resume;
        this.imageView = imageView;
    }

    public Livre(String categorie, String titre, String auteur, String resume, ImageView imageView) {
        this.categorie = categorie;
        this.titre = titre;
        this.auteur = auteur;
        this.resume = resume;
        this.imageView = imageView;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public String getCategorie() {
        return categorie;
    }

    public Livre(String titre, String auteur, String resume, ImageView imageView) {
        this.titre = titre;
        this.auteur = auteur;
        this.resume = resume;
        this.imageView = imageView;
    }

    public Livre() {

    }

    public String getTitre() {
        return titre;
    }

    public String getAuteur() {
        return auteur;
    }

    public String getAnneeEdition() {
        return anneeEdition;
    }

    public String getResume() {
        return resume;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    public void setAnneeEdition(String anneeEdition) {
        this.anneeEdition = anneeEdition;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public void setImageView(ImageView imageView) {
        this.imageView = imageView;
    }

    public boolean containKeyWord (String word){
        if (this.titre.toLowerCase().indexOf(word.toLowerCase()) != -1
               || this.categorie.toLowerCase().indexOf(word.toLowerCase()) != -1
                    || this.auteur.toLowerCase().indexOf(word.toLowerCase()) != -1
                        || this.resume.toLowerCase().indexOf(word.toLowerCase()) != -1) {
            return true;
        } else {
            return false;
        }
    }


    public boolean containAllKeyWords (String sentence){
        String[] words = sentence.split("\\s+");
        boolean bool = true;
        int i=0;
        while (i<words.length && bool==true){
            if (this.containKeyWord(words[i])==false) {
                bool=false;
            }
            else {
                i++;
            }
        }
        return bool;
    }
}
