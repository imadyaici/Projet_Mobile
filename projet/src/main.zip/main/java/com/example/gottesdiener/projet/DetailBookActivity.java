package com.example.gottesdiener.projet;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class DetailBookActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_book);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.hide();
        Bundle extras = getIntent().getExtras();
        if (extras!=null) {
            TextView textView = (TextView) findViewById(R.id.titre);
            TextView textView2 = (TextView) findViewById(R.id.auteur);
            TextView textView3 = (TextView) findViewById(R.id.categorie);
            TextView textView4 = (TextView) findViewById(R.id.resume);
            TextView textView5 = (TextView) findViewById(R.id.annee);
            textView.setText(extras.getString("titre"));
            textView2.setText(extras.getString("auteur"));
            textView3.setText(extras.getString("categorie"));
            textView4.setText(extras.getString("resume"));
            textView5.setText(extras.getString("annee"));
            //imageView1.setBackground(imageView.getBackground());
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_detail_book, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void showComment(View view){
        Intent intent = new Intent(this,CommentairesActivity.class);
        this.startActivityForResult(intent,1000);
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void marquerInteressante(View view){
        ImageView imageView = (ImageView) view;
        imageView.setBackground(getResources().getDrawable(R.drawable.gold_star));
    }
}
